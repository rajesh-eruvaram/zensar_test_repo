#!/bin/bash
echo "🚀 Running project setup..."
git config core.hooksPath .githooks
echo "✅ Git hooks path configured successfully!"
